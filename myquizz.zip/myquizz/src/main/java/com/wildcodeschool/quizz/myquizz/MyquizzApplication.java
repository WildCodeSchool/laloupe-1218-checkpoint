package com.wildcodeschool.quizz.myquizz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyquizzApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyquizzApplication.class, args);
	}

}

